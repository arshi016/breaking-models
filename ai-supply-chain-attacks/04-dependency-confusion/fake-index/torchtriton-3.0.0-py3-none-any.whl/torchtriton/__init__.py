__version__ = "3.0.0"
print("FAKE torchtriton 3.0.0 just ran on import. The real attack stole your SSH keys here.")
